package de.tuefteltyp.virtualhopper.client;

import de.tuefteltyp.virtualhopper.VirtualHopperBlockEntity;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;

/** Nine target slots with independent ghost filters. All modifications are checked server-side. */
public final class VirtualHopperTargetsScreen extends Screen {
    private final BlockPos pos;
    private final String[] names = new String[9];
    private final String[][] templates = new String[9][9];
    private final boolean[] enabled = new boolean[9];
    private final boolean[] blacklist = new boolean[9];
    private final Button[] itemButtons = new Button[9];
    private EditBox name;
    private Button modeButton;
    private Button enableButton;
    private Button listButton;
    private Button filterModeButton;
    private int selected;
    private int mode;
    private int selectedItem;
    private String notice = "";
    private boolean initialized;

    public VirtualHopperTargetsScreen(BlockPos pos) {
        super(Component.translatable("screen.virtualhopper.targets.title"));
        this.pos = pos;
        java.util.Arrays.fill(names, "");
        for (String[] row : templates) java.util.Arrays.fill(row, "");
    }
    private String coords() { return pos.getX() + " " + pos.getY() + " " + pos.getZ(); }
    private void send(String command) {
        if (minecraft != null && minecraft.getConnection() != null) minecraft.getConnection().sendCommand("virtualhopper " + command);
    }
    private void read() {
        if (initialized || minecraft == null || minecraft.level == null) return;
        if (minecraft.level.getBlockEntity(pos) instanceof VirtualHopperBlockEntity hopper) {
            mode = hopper.getDistributionMode();
            for (int t = 0; t < 9; t++) {
                names[t] = hopper.getTargetName(t);
                enabled[t] = hopper.isDestinationFilterEnabled(t);
                blacklist[t] = hopper.isDestinationFilterBlacklist(t);
                for (int i = 0; i < 9; i++) templates[t][i] = hopper.getDestinationFilterItem(t, i);
            }
        }
        initialized = true;
    }
    @Override protected void init() {
        read();
        int x = width / 2 - 170, y = height / 2 - 122;
        for (int i = 0; i < 9; i++) {
            final int index = i;
            addRenderableWidget(Button.builder(Component.literal(Integer.toString(i + 1)), b -> select(index))
                .bounds(x + 6 + i * 37, y + 26, 34, 20).build());
        }
        name = addRenderableWidget(new EditBox(font, x + 6, y + 56, 223, 20,
                Component.translatable("screen.virtualhopper.target_short")));
        name.setMaxLength(32);
        name.setValue(names[selected]);
        addRenderableWidget(Button.builder(Component.translatable("screen.virtualhopper.targets.save"), b -> {
            String value = name.getValue().trim();
            if (!value.isEmpty() && !value.matches("[a-zA-Z0-9_-]{1,32}")) { notice = "screen.virtualhopper.invalid"; return; }
            send("targetslot " + coords() + " " + (selected + 1) + " " + (value.isEmpty() ? "none" : value));
            names[selected] = value;
            notice = "screen.virtualhopper.sent";
        }).bounds(x + 236, y + 56, 97, 20).build());
        modeButton = addRenderableWidget(Button.builder(Component.empty(), b -> {
            mode = (mode + 1) % 3;
            send("distribution " + coords() + " " + new String[]{"round_robin","priority","balanced"}[mode]);
            refresh();
        }).bounds(x + 6, y + 84, 327, 20).build());
        enableButton = addRenderableWidget(Button.builder(Component.empty(), b -> {
            enabled[selected] = !enabled[selected];
            send("targetfilter " + coords() + " " + (selected + 1) + " enabled " + (enabled[selected] ? "on" : "off"));
            refresh();
        }).bounds(x + 6, y + 112, 160, 20).build());
        filterModeButton = addRenderableWidget(Button.builder(Component.empty(), b -> {
            blacklist[selected] = !blacklist[selected];
            send("targetfilter " + coords() + " " + (selected + 1) + " mode " + (blacklist[selected] ? "blacklist" : "whitelist"));
            refresh();
        }).bounds(x + 173, y + 112, 160, 20).build());
        for (int i = 0; i < 9; i++) {
            final int slot = i;
            itemButtons[i] = addRenderableWidget(Button.builder(Component.literal("+"), b -> pick(slot))
                .bounds(x + 6 + i * 37, y + 145, 34, 28).build());
        }
        addRenderableWidget(Button.builder(Component.translatable("screen.virtualhopper.filter.clear"), b -> {
            templates[selected][selectedItem] = "";
            send("targetfilter " + coords() + " " + (selected + 1) + " slot" + (selectedItem + 1) + " none");
            refresh();
        }).bounds(x + 6, y + 191, 160, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.virtualhopper.filter.back"), b -> onClose())
            .bounds(x + 173, y + 191, 160, 20).build());
        refresh();
    }
    private void select(int index) { selected = index; selectedItem = 0; name.setValue(names[selected]); refresh(); }
    private void pick(int slot) {
        selectedItem = slot;
        final int target = selected;
        if (minecraft != null) minecraft.gui.setScreen(new VirtualHopperItemPickerScreen(this, id -> {
            templates[target][slot] = id;
            send("targetfilter " + coords() + " " + (target + 1) + " slot" + (slot + 1) + " " + id);
            refresh();
        }));
    }
    private void refresh() {
        if (modeButton == null) return;
        modeButton.setMessage(Component.translatable("screen.virtualhopper.targets.mode." + mode));
        enableButton.setMessage(Component.translatable(enabled[selected] ? "screen.virtualhopper.filter.enable_on" : "screen.virtualhopper.filter.enable_off"));
        filterModeButton.setMessage(Component.translatable(blacklist[selected] ? "screen.virtualhopper.filter.blacklist" : "screen.virtualhopper.filter.whitelist"));
        for (int i = 0; i < 9; i++) itemButtons[i].setMessage(Component.literal(templates[selected][i].isEmpty() ? "+" : ""));
    }
    @Override public void onClose() {
        if (minecraft != null) minecraft.gui.setScreen(new VirtualHopperScreen(pos));
    }
    @Override public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        int x = width / 2 - 170, y = height / 2 - 122;
        graphics.fill(x - 8, y - 8, x + 341, y + 233, 0xF0091722);
        graphics.outline(x - 8, y - 8, 349, 241, 0xFF14CFE2);
        graphics.text(font, title, x + 6, y + 4, 0xFFCEFFFF, true);
        graphics.text(font, Component.literal((selected + 1) + ": " + (names[selected].isEmpty() ? "-" : names[selected])), x + 8, y + 182, 0xFFD8F9FF, false);
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        for (int i = 0; i < 9; i++) {
            String id = templates[selected][i];
            if (id.isEmpty()) continue;
            Identifier parsed = Identifier.tryParse(id);
            if (parsed == null) continue;
            var item = BuiltInRegistries.ITEM.getOptional(parsed);
            if (item.isPresent()) graphics.item(new ItemStack(item.get()), x + 14 + i * 37, y + 151);
        }
        if (!notice.isEmpty()) graphics.text(font, Component.translatable(notice), x + 8, y + 216, 0xFFBDF39D, false);
    }
}
