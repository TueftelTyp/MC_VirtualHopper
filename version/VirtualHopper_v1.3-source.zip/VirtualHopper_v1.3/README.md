# VirtualHopper_v1.3 (Minecraft 26.3 / Fabric)

Author: TueftelTyp

## New in v1.3
- Reworked dark obsidian-blue hopper textures with cyan highlights, using the original Minecraft hopper model.
- Compact, foldable configuration screen. Open it with Sneak + Right Click on the Virtual Hopper.
- Separate fields for a unique hopper name and a target hopper name; save each with the adjacent button.
- The **Open inventory** button returns directly to the regular five-slot hopper inventory.
- Target names can be cleared by leaving the target field blank and clicking **Save target**.
- English and German text for the revised GUI.
- Windows build script uses `gradle --no-daemon clean build` to avoid a conflicting daemon-stop command.

## Important UI behavior
Normal right click opens the vanilla five-slot inventory. Sneak + right click opens the compact configuration GUI. The configuration window is a separate screen rather than an overlay on the inventory: this preserves reliable vanilla drag/drop slot interactions. The configuration button collapses and expands the fields.

## Build
Java 25, Gradle 9.8.2, Minecraft 26.3 Fabric toolchain. Run `build-windows.bat` or `gradle --no-daemon clean build`.

## Scope and limitations
This release has not been compiled or tested against the complete 26.3 toolchain in this environment. Previous core transfer and chunk-loading logic is retained. Endpoint persistence, access controls, unusual sided inventories and rich target browsing still require separate hardening; do not treat this as a fully audited production-server release.

Recipe: `src/main/resources/data/virtualhopper/recipe/virtual_hopper.json`.
Localization: `src/main/resources/assets/virtualhopper/lang/`.
