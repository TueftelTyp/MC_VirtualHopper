# VirtualHopper_v1.5 (Minecraft 26.3 / Fabric)

Author: TueftelTyp

## New in v1.5
- Reworked dark obsidian-blue hopper textures with cyan highlights, using the original Minecraft hopper model.
- Compact, foldable configuration screen. Open it with Sneak + Right Click on the Virtual Hopper.
- Separate fields for a unique hopper name and a target hopper name; save each with the adjacent button.
- The **Open inventory** button returns directly to the regular five-slot hopper inventory.
- Target names can be cleared by leaving the target field blank and clicking **Save target**.
- English and German text for the revised GUI.
- Windows build script uses `gradle --no-daemon clean build` to avoid a conflicting daemon-stop command.

## Important UI behavior
Normal right click opens the vanilla five-slot inventory. Sneak + right click opens the compact configuration GUI. The configuration window is a separate screen rather than an overlay on the inventory: this preserves reliable vanilla drag/drop slot interactions. The configuration button collapses and expands the fields.

## Build
Java 25, Gradle 9.8.2, Minecraft 26.3 Fabric toolchain. Run `build-windows.bat` or `gradle --no-daemon clean build`.

## Scope and limitations
This release has not been compiled or tested against the complete 26.3 toolchain in this environment. Previous core transfer and chunk-loading logic is retained. Endpoint persistence, access controls, unusual sided inventories and rich target browsing still require separate hardening; do not treat this as a fully audited production-server release.

Recipe: `src/main/resources/data/virtualhopper/recipe/virtual_hopper.json`.
Localization: `src/main/resources/assets/virtualhopper/lang/`.


## v1.5 GUI and mod icon fix
- Normal right click opens the 5-slot vanilla hopper inventory with a **Settings** button on its right edge.
- That button opens the separate compact configuration with Name / Target text fields. Sneak + right click also opens configuration directly.
- The configuration uses chat commands for submitting changes; acknowledgements appear in chat.
- The mod has a real 128x128 PNG logo declared via `fabric.mod.json` for Mod Menu.
- Warning: reopening the inventory through the configuration sends a command and closes the settings screen; the server then opens the inventory.
- The native inventory texture remains vanilla by design to preserve slot behavior. The block retains its current dark-cyan texture.
- This version has **not** been compiled or tested in Minecraft 26.3; verify with Java 25 and `gradle --no-daemon clean build`.


## v1.5 client compile fix
Minecraft 26.3 moved setScreen to Minecraft.gui.setScreen(Screen). Both client calls have been updated. A full Fabric/Java 25 build is not verified in this environment.
