# Virtual Hopper v1.0

Fabric mod for Minecraft **26.3**. Author: **TueftelTyp**.

## Build (Windows)
Install **JDK 25** and **Gradle 9.7.1 or newer** (or generate a Gradle wrapper with `gradle wrapper`).
Open the project directory and run `gradle build` (or `gradlew.bat build` after generating wrapper).
Place the resulting JAR from `build/libs` into the `mods` directory alongside Fabric API.

**Status:** Uncompiled initial source release. Compilation and in-game compatibility must be checked locally.

## Playing
1. Craft a Virtual Hopper using the JSON recipe in `src/main/resources/data/virtualhopper/recipe/virtual_hopper.json`.
2. Place at least two Virtual Hoppers, both in loaded chunks.
3. **Sneak + right click** a hopper to configure it. Normal right click opens the familiar five-slot vanilla hopper inventory.
4. Save a unique name on the receiving hopper, e.g. `Storage`.
5. Set `Storage` as the source hopper's destination. Items are transmitted one at a time at the configured interval.
6. Use **Known targets in chat** to see currently indexed names; entering the desired name in the GUI selects it. Blank target disables remote routing and restores local output through the hopper's facing side.

**Limitations in v1.0:** The GUI does not yet have an in-window previous/next target picker. The target list appears in chat. Only already loaded targets can be selected. Targets in unloaded chunks are not force-loaded. Name lookup is rebuilt as chunks tick; names aren't globally discoverable when chunks haven't loaded since restart. This release does not include server-side ownership/claim integration, comprehensive sided inventory compatibility, or full vanilla hopper minecart interactions. Transfers are intended to be single-threaded and do not produce items unless the destination can receive them. Use a backup for first testing.

## Configuration
After first run, edit `config/virtualhopper.json`:

```json
{
  "transferIntervalTicks": 8,
  "allowCrossDimension": true,
  "collectDroppedItems": true
}
```

Restart game/server after changes. Source recipe can be edited before build or overridden in a datapack.

## Commands
`/virtualhopper list` shows names of known Virtual Hoppers.
`/virtualhopper name x y z Name` sets a name when close enough.
`/virtualhopper target x y z Name` links to a known loaded target when close enough.
`/virtualhopper target x y z none` removes remote routing.

Translation files: `assets/virtualhopper/lang/de_de.json` and `en_us.json`.

## v1.1 Buildfix
- Zwei ueberzaehlige schliessende Klammern in der Brigadier-Befehlsregistrierung (name und target) entfernt.
- Gradle-Build ist noch vom Nutzer zu pruefen.
