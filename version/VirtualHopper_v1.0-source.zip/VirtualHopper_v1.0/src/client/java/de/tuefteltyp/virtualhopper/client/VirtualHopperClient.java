package de.tuefteltyp.virtualhopper.client;

import de.tuefteltyp.virtualhopper.VirtualHopper;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionResult;

public final class VirtualHopperClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        UseBlockCallback.EVENT.register((player, level, hand, result) -> {
            if (level.isClientSide() && level.getBlockState(result.getBlockPos()).is(VirtualHopper.BLOCK) && player.isShiftKeyDown()) {
                Minecraft.getInstance().gui.setScreen(new VirtualHopperScreen(result.getBlockPos()));
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        });
    }
}
