package de.tuefteltyp.virtualhopper.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

public final class VirtualHopperScreen extends Screen {
    private final BlockPos pos;
    private EditBox name;
    private EditBox target;
    private String status = "";
    public VirtualHopperScreen(BlockPos pos) { super(Component.translatable("screen.virtualhopper.title")); this.pos = pos; }
    @Override protected void init() {
        int x=width/2-115, y=height/2-90;
        name = new EditBox(font,x,y+33,230,20,Component.translatable("screen.virtualhopper.name"));
        name.setMaxLength(32);
        addRenderableWidget(name);
        target = new EditBox(font,x,y+87,230,20,Component.translatable("screen.virtualhopper.target"));
        target.setMaxLength(32);
        addRenderableWidget(target);
        addRenderableWidget(Button.builder(Component.translatable("screen.virtualhopper.set_name"), b -> {
            if (name.getValue().matches("[a-zA-Z0-9_-]{1,32}")) {
                send("virtualhopper name "+pos.getX()+" "+pos.getY()+" "+pos.getZ()+" "+name.getValue());
                status = "screen.virtualhopper.sent";
            } else status = "screen.virtualhopper.invalid";
        }).bounds(x,y+112,110,20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.virtualhopper.set_target"), b -> {
            String value=target.getValue().trim();
            if (value.isEmpty()) value="none";
            if (value.matches("[a-zA-Z0-9_-]{1,32}")) {
                send("virtualhopper target "+pos.getX()+" "+pos.getY()+" "+pos.getZ()+" "+value);
                status="screen.virtualhopper.sent";
            } else status="screen.virtualhopper.invalid";
        }).bounds(x+120,y+112,110,20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.virtualhopper.list"), b -> {
            send("virtualhopper list");
            Minecraft.getInstance().gui.setScreen(null);
        }).bounds(x,y+140,110,20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> Minecraft.getInstance().gui.setScreen(null))
            .bounds(x+120,y+140,110,20).build());
    }
    private void send(String command) {
        if (minecraft != null && minecraft.getConnection() != null) minecraft.getConnection().sendCommand(command);
    }
    @Override public void extractRenderState(GuiGraphicsExtractor graphics,int mouseX,int mouseY,float delta) {
        int x=width/2-115,y=height/2-90;
        graphics.fill(x-12,y-21,x+242,y+185,0xD9121720);
        graphics.outline(x-12,y-21,254,206,0xFF399BB7);
        graphics.text(font,Component.translatable("screen.virtualhopper.title"),x,y-12,0xFFFFFFFF,true);
        graphics.text(font,Component.translatable("screen.virtualhopper.name"),x,y+18,0xFFC6E9F4,false);
        graphics.text(font,Component.translatable("screen.virtualhopper.target"),x,y+72,0xFFC6E9F4,false);
        graphics.text(font,Component.translatable("screen.virtualhopper.hint"),x,y+166,0xFFB0B0B0,false);
        super.extractRenderState(graphics,mouseX,mouseY,delta);
        if (!status.isBlank()) graphics.text(font,Component.translatable(status),x,y+190,0xFFBFEABC,false);
    }
}
