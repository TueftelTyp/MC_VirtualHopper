@echo off
where gradle >nul 2>nul
if errorlevel 1 (
 echo Gradle not found. Install Gradle 9.7.1 and JDK 25 first.
 pause
 exit /b 1
)
gradle build
pause
